# The Memory Sheet 

The **MemorySheet** provides a place to manually save cell values for later reference. It also automatically stores clipboard data when rows, cells or columns are copied.

- {help.commands.memo_cell}
- {help.commands.memo_aggregate}
- {help.commands.open_memos}
