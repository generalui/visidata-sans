# Split VisiData into two panes

Use split panes to view two sheets at once.

## Open and Close a new split

- {help.commands.splitwin_half}
- {help.commands.splitwin_close}
- {help.commands.splitwin_input}

## Modify the split plane view

- {help.commands.splitwin_swap}
- Additionally, click on the inactive pane with the mouse to jump to it.
- {help.commands.splitwin_swap_pane}
